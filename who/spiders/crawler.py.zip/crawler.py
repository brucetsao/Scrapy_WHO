import scrapy
from bs4 import BeautifulSoup


class whoCrawler(scrapy.Spider):
    name = 'who'
    start_urls = ['http://www.whocc.no/atc_ddd_index/?code=A']

    def parse(self, response):
        res = BeautifulSoup(response.body)
        domain = 'http://www.whocc.no/atc_ddd_index/'
        for news in res.select('p b'):
            # print(news.select('h1')[0].text)
            print(domain + news.select('a')[0]['href'][2:])
            try:
                yield scrapy.Request(domain + news.select('a')[0]['href'][2:], callback=self.parse_second)
            except:
                pass


def parse_second(self, response):
    res = BeautifulSoup(response)
    # appleItem = WhoItem()
    domain = 'http://www.whocc.no/atc_ddd_index/'
    for news2 in res.select('p b'):
        print(domain + news2.select('a')[0]['href'][2:])
        yield scrapy.Request(domain + news2.select('a')[0]['href'][2:], callback=self.parse_third)


def parse_third(self, response):
    res = BeautifulSoup(response)
    # appleItem = WhoItem()
    domain = 'http://www.whocc.no/atc_ddd_index/'
    for news3 in res.select('p b'):
        print(domain + news3.select('a')[0]['href'][2:])
        yield scrapy.Request(domain + news3.select('a')[0]['href'][2:], callback=self.parse_detail)


def parse_detail(self, response):
    res = BeautifulSoup(response)
    for code in res.select('tr'):
        code = print(res.select('td')[0].text)
        if code != "ATC code":
            print(res.select('td')[0].text)
    for name in res.select('td a'):
        print(name.text)
